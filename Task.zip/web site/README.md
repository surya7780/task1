*Real Estate Listings

This project showcases a simple real estate listing platform. It displays property details like price, location, and description, and allows users to filter listings by price range and location.

*How to run code

1. Clone this repository or download the ZIP file.
2. Open `index1.html` in your browser to view the landing page.
3. The page is responsive and allows dynamic filtering based on location and price.

*Techmologies used
- HTML
- CSS
- JavaScript
